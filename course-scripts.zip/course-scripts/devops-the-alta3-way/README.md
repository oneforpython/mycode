# devops-the-alta3-way
set up scripts for devops course.
