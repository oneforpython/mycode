import lodash from "lodash";

console.log(lodash);
