#!/usr/bin/bash

echo STARTING ----------
kubectl apply -f ~/mycode/yaml/ctce-drill-security-contexts.yaml
echo END OF SETUP ----------
