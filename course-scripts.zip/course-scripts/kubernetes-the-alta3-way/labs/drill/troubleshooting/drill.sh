#!/usr/bin/bash

echo STARTING ----------
kubectl apply -f ~/mycode/yaml/ctce-drill-debugging.yaml
echo END OF SETUP ----------
