#!/usr/bin/bash

echo STARTING ----------

echo END OF SETUP ----------
