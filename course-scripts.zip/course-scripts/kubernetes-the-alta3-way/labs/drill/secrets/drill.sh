#!/usr/bin/bash

echo STARTING ----------
kubectl apply -f ~/mycode/yaml/ctce-drill-secrets.yaml
echo END OF SETUP ----------
