#!/bin/bash
set -euo pipefail

kubectl config delete-context dev-context
