#!/bin/bash
set -euo pipefail

echo "[-] No teardown"
"
