#!/usr/bin/bash

echo STARTING ----------
kubectl apply -f ~/mycode/yaml/ctce-drill-deployments.yaml
echo END OF SETUP ----------
