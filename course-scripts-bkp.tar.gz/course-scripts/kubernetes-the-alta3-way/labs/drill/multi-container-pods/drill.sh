#!/usr/bin/bash

echo STARTING ----------
kubectl apply -f ~/mycode/yaml/ctce-drill-multi-container-pods.yaml
echo END OF SETUP ----------
