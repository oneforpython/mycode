#!/bin/bash
set -euo pipefail
echo "Teardown complete"
