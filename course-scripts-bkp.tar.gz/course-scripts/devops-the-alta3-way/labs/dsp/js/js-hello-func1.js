greeting = "Hello"

# We can use this symbol to create comments in our code in Python

def say_hello():
    print(greeting)
    greeting = "Howdy!"
    print(greeting)

