const deleteDuplicates = () => {
  var cleanArray = require('uniq');
  var names = ["Jim", "John", "Jim", "Aparnaa", "Jordan", "John", "Emilia", "Juan"]

console.log(cleanArray(names))
}

deleteDuplicates()
