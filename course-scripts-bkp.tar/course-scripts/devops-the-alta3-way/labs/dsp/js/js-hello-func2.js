let greeting = "Hello"

// We can use a pair of these slashes to create comments in JavaScript

function sayHello(){
    console.log(greeting) //<= the console object has a "log" method which
    prints to the console
        greeting = "Howdy!" //<= we don't need a keyword to reset the value
        of variables once they are created. 
            console.log(greeting)
            }
                    

