#!/bin/bash
set -euo pipefail

kubectl config use-context kubernetes-the-alta3-way
