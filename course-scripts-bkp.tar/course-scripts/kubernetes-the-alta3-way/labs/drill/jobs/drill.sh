#!/usr/bin/bash

echo STARTING ----------
kubectl apply -f ~/mycode/yaml/ctce-drill-jobs.yaml
echo END OF SETUP ----------
